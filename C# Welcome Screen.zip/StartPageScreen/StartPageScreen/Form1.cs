﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StartPageScreen
{
    public partial class Form1 : Form
    {
        int i = 2,count=1;
        bool flag = true;
        public Form1()
        {
            InitializeComponent();
        }

        void ColorChange()
        {
            p2.BackColor = Color.SlateBlue;
            p3.BackColor = Color.SlateBlue;
            p4.BackColor = Color.SlateBlue;
            p5.BackColor = Color.SlateBlue;
            p6.BackColor = Color.SlateBlue;
            p7.BackColor = Color.SlateBlue;
            p8.BackColor = Color.SlateBlue;
            p9.BackColor = Color.SlateBlue;
            p10.BackColor = Color.SlateBlue;
            p11.BackColor = Color.SlateBlue;
            p12.BackColor = Color.SlateBlue;
            p13.BackColor = Color.SlateBlue;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //progressBar1.Increment(1);
            if (i == 14)
                i = 2;
            ColorChange();
                switch (i)
                {
                    case 2: p2.BackColor = Color.WhiteSmoke;
                        break;
                    case 3: p3.BackColor = Color.WhiteSmoke;
                        break;
                    case 4: p4.BackColor = Color.WhiteSmoke;
                        break;
                    case 5: p5.BackColor = Color.WhiteSmoke;
                        break;
                    case 6: p6.BackColor = Color.WhiteSmoke;
                        break;
                    case 7: p7.BackColor = Color.WhiteSmoke;
                        break;
                    case 8: p8.BackColor = Color.WhiteSmoke;
                        break;
                    case 9: p9.BackColor = Color.WhiteSmoke;
                        break;
                    case 10: p10.BackColor = Color.WhiteSmoke;
                        break;
                    case 11: p11.BackColor = Color.WhiteSmoke;
                        break;
                    case 12: p12.BackColor = Color.WhiteSmoke;
                        break;
                    case 13: p13.BackColor = Color.WhiteSmoke;
                        break;
            }

                i++;
                count++;

            if(count==27)
            {
                timer1.Stop();
                MessageBox.Show("Timer Stopped");
                /***
                 * 
                 *     next page code here
                 * 
                 * 
                 * */
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
