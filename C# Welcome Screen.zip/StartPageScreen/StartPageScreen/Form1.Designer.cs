﻿namespace StartPageScreen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Panel();
            this.p3 = new System.Windows.Forms.Panel();
            this.p4 = new System.Windows.Forms.Panel();
            this.p5 = new System.Windows.Forms.Panel();
            this.p6 = new System.Windows.Forms.Panel();
            this.p7 = new System.Windows.Forms.Panel();
            this.p8 = new System.Windows.Forms.Panel();
            this.p13 = new System.Windows.Forms.Panel();
            this.p12 = new System.Windows.Forms.Panel();
            this.p11 = new System.Windows.Forms.Panel();
            this.p10 = new System.Windows.Forms.Panel();
            this.p9 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(511, 21);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(24, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(374, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Stock Management System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(27, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Version 1.0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(362, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "*All Rights Reserved";
            // 
            // p2
            // 
            this.p2.BackColor = System.Drawing.Color.SlateBlue;
            this.p2.Location = new System.Drawing.Point(216, 149);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(15, 15);
            this.p2.TabIndex = 5;
            // 
            // p3
            // 
            this.p3.BackColor = System.Drawing.Color.SlateBlue;
            this.p3.Location = new System.Drawing.Point(237, 149);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(15, 15);
            this.p3.TabIndex = 6;
            // 
            // p4
            // 
            this.p4.BackColor = System.Drawing.Color.SlateBlue;
            this.p4.Location = new System.Drawing.Point(258, 149);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(15, 15);
            this.p4.TabIndex = 6;
            // 
            // p5
            // 
            this.p5.BackColor = System.Drawing.Color.SlateBlue;
            this.p5.Location = new System.Drawing.Point(279, 149);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(15, 15);
            this.p5.TabIndex = 7;
            // 
            // p6
            // 
            this.p6.BackColor = System.Drawing.Color.SlateBlue;
            this.p6.Location = new System.Drawing.Point(279, 170);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(15, 15);
            this.p6.TabIndex = 8;
            // 
            // p7
            // 
            this.p7.BackColor = System.Drawing.Color.SlateBlue;
            this.p7.Location = new System.Drawing.Point(279, 191);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(15, 15);
            this.p7.TabIndex = 9;
            // 
            // p8
            // 
            this.p8.BackColor = System.Drawing.Color.SlateBlue;
            this.p8.Location = new System.Drawing.Point(279, 212);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(15, 15);
            this.p8.TabIndex = 10;
            // 
            // p13
            // 
            this.p13.BackColor = System.Drawing.Color.SlateBlue;
            this.p13.Location = new System.Drawing.Point(216, 170);
            this.p13.Name = "p13";
            this.p13.Size = new System.Drawing.Size(15, 15);
            this.p13.TabIndex = 11;
            // 
            // p12
            // 
            this.p12.BackColor = System.Drawing.Color.SlateBlue;
            this.p12.Location = new System.Drawing.Point(216, 191);
            this.p12.Name = "p12";
            this.p12.Size = new System.Drawing.Size(15, 15);
            this.p12.TabIndex = 12;
            // 
            // p11
            // 
            this.p11.BackColor = System.Drawing.Color.SlateBlue;
            this.p11.Location = new System.Drawing.Point(216, 212);
            this.p11.Name = "p11";
            this.p11.Size = new System.Drawing.Size(15, 15);
            this.p11.TabIndex = 13;
            // 
            // p10
            // 
            this.p10.BackColor = System.Drawing.Color.SlateBlue;
            this.p10.Location = new System.Drawing.Point(237, 212);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(15, 15);
            this.p10.TabIndex = 14;
            // 
            // p9
            // 
            this.p9.BackColor = System.Drawing.Color.SlateBlue;
            this.p9.Location = new System.Drawing.Point(258, 212);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(15, 15);
            this.p9.TabIndex = 15;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(511, 315);
            this.Controls.Add(this.p9);
            this.Controls.Add(this.p10);
            this.Controls.Add(this.p11);
            this.Controls.Add(this.p12);
            this.Controls.Add(this.p13);
            this.Controls.Add(this.p8);
            this.Controls.Add(this.p7);
            this.Controls.Add(this.p6);
            this.Controls.Add(this.p5);
            this.Controls.Add(this.p4);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel p2;
        private System.Windows.Forms.Panel p3;
        private System.Windows.Forms.Panel p4;
        private System.Windows.Forms.Panel p5;
        private System.Windows.Forms.Panel p6;
        private System.Windows.Forms.Panel p7;
        private System.Windows.Forms.Panel p8;
        private System.Windows.Forms.Panel p13;
        private System.Windows.Forms.Panel p12;
        private System.Windows.Forms.Panel p11;
        private System.Windows.Forms.Panel p10;
        private System.Windows.Forms.Panel p9;
        private System.Windows.Forms.Timer timer1;
    }
}

